export * from '@primeuix/styled';
