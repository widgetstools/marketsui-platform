module.exports = {
  hoge: 'fuga',
};
