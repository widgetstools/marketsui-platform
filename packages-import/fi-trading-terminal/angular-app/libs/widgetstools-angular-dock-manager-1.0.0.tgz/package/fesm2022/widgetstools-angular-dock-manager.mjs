import * as i0 from '@angular/core';
import { EventEmitter, createComponent, ViewChild, Output, Input, ChangeDetectionStrategy, Component, Injectable } from '@angular/core';
import { DockviewComponent } from '@widgetstools/dock-manager-core';
export { DockviewApi, DockviewComponent, EventEmitter, clearLocalStorage, createDefaultState, createTheme, deserialize, dockReducer, draculaDark, exportToFile, findAllTabGroups, findFirstTabGroup, findTabGroupById, findTabGroupForPanel, forestDark, getThemeByName, getThemesByMode, githubLight, importFromFile, lavenderLight, loadFromLocalStorage, midnightDark, mintLight, nordDark, saveToLocalStorage, sepiaLight, serialize, slateDark, solarizedDark, solarizedLight, themes, validateState, vsCodeDark, vsCodeLight, warmLight } from '@widgetstools/dock-manager-core';
import { BehaviorSubject } from 'rxjs';

/**
 * Thin Angular wrapper around the core DockviewComponent.
 *
 * All DOM rendering, event handling, and layout logic lives in core.
 * Angular only provides panel content via dynamic component creation.
 *
 * Zoneless: Uses ChangeDetectorRef.markForCheck() instead of NgZone.
 * Compatible with both zone.js and zoneless (provideZonelessChangeDetection).
 */
class DockManagerCoreComponent {
    cdr;
    appRef;
    envInjector;
    /** Initial state for the dock manager */
    initialState;
    /**
     * Widget registry: maps panel.widgetType strings to Angular component classes.
     * When provided, panels are automatically rendered using createComponent().
     * Each widget component should accept `api` and `panel` inputs.
     */
    widgets;
    /** Content renderer — called when a panel needs content mounted into a container.
     *  Used as fallback when `widgets` registry doesn't match the panel's widgetType. */
    createContent;
    /** Optional custom tab renderer */
    createTab;
    /** Optional header actions renderer */
    createHeaderActions;
    /** Optional watermark renderer for empty tab groups */
    createWatermark;
    /** Theme: 'light', 'dark', or a DockTheme object */
    theme = 'light';
    /** Whether to show edge dock indicators. Defaults to true. */
    allowRootDock;
    /** Emits when the dock manager is initialized with the DockviewApi for programmatic control */
    ready = new EventEmitter();
    /** Emits when state changes */
    stateChange = new EventEmitter();
    /** Emits before a panel close (preventable) */
    willClose = new EventEmitter();
    /** Emits before a drop (preventable) */
    willDrop = new EventEmitter();
    /** Emits when the user explicitly saves the layout via context menu */
    saveLayout = new EventEmitter();
    containerRef;
    dock = null;
    constructor(cdr, appRef, envInjector) {
        this.cdr = cdr;
        this.appRef = appRef;
        this.envInjector = envInjector;
    }
    ngAfterViewInit() {
        const options = {
            initialState: this.initialState,
            theme: this.theme,
            allowRootDock: this.allowRootDock,
            createContent: (panelId, container, api) => {
                // Try widget registry first
                // Note: this.dock may be null during initial construction, so fall back to initialState
                const state = this.dock?.getState() ?? this.initialState;
                const panel = state?.panels.get(panelId);
                const widgetType = panel?.widgetType || '';
                const WidgetClass = this.widgets?.[widgetType];
                if (WidgetClass) {
                    return this.mountComponent(WidgetClass, container, api, panel);
                }
                // Fall back to createContent callback
                if (this.createContent) {
                    const disposable = this.createContent(panelId, container, api);
                    this.cdr.markForCheck();
                    return disposable;
                }
                // Nothing to render
                return { dispose: () => { } };
            },
            createTab: this.createTab
                ? (panelId, container, isActive) => {
                    const disposable = this.createTab(panelId, container, isActive);
                    this.cdr.markForCheck();
                    return disposable;
                }
                : undefined,
            createHeaderActions: this.createHeaderActions
                ? (slot, tabGroupId, container) => {
                    const disposable = this.createHeaderActions(slot, tabGroupId, container);
                    this.cdr.markForCheck();
                    return disposable;
                }
                : undefined,
            createWatermark: this.createWatermark
                ? (container) => {
                    const disposable = this.createWatermark(container);
                    this.cdr.markForCheck();
                    return disposable;
                }
                : undefined,
            onStateChange: (state) => {
                this.stateChange.emit(state);
                this.cdr.markForCheck();
            },
            onWillClose: (event, panelId) => {
                this.willClose.emit({ event, panelId });
                this.cdr.markForCheck();
            },
            onWillDrop: (event, sourceId, targetId, position) => {
                this.willDrop.emit({ event, sourceId, targetId, position });
                this.cdr.markForCheck();
            },
            onSaveLayout: (state) => {
                this.saveLayout.emit(state);
                this.cdr.markForCheck();
            },
        };
        this.dock = new DockviewComponent(this.containerRef.nativeElement, options);
        // Emit the API for easy programmatic access
        this.ready.emit(this.dock.api);
    }
    ngOnChanges(changes) {
        if (!this.dock)
            return;
        const updates = {};
        if (changes['theme'] && !changes['theme'].firstChange)
            updates.theme = this.theme;
        if (changes['allowRootDock'] && !changes['allowRootDock'].firstChange)
            updates.allowRootDock = this.allowRootDock;
        if (Object.keys(updates).length > 0)
            this.dock.updateOptions(updates);
    }
    ngOnDestroy() {
        this.dock?.dispose();
        this.dock = null;
    }
    /** Dispatch an action to the dock manager */
    dispatch(action) {
        this.dock?.dispatch(action);
    }
    /** Get current state */
    getState() {
        return this.dock?.getState() ?? null;
    }
    /** Get the underlying DockviewComponent instance */
    getInstance() {
        return this.dock;
    }
    /** Get the DockviewApi for programmatic control */
    getApi() {
        return this.dock?.api ?? null;
    }
    /** Mount an Angular component into a container element */
    mountComponent(componentClass, container, api, panel) {
        const hostEl = document.createElement('div');
        hostEl.style.cssText = 'width:100%;height:100%;color:inherit';
        container.appendChild(hostEl);
        const ref = createComponent(componentClass, {
            hostElement: hostEl,
            environmentInjector: this.envInjector,
        });
        ref.setInput('api', api);
        ref.setInput('panel', panel);
        this.appRef.attachView(ref.hostView);
        queueMicrotask(() => ref.changeDetectorRef.detectChanges());
        return {
            dispose: () => {
                this.appRef.detachView(ref.hostView);
                ref.destroy();
                container.innerHTML = '';
            },
        };
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: DockManagerCoreComponent, deps: [{ token: i0.ChangeDetectorRef }, { token: i0.ApplicationRef }, { token: i0.EnvironmentInjector }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.0", type: DockManagerCoreComponent, isStandalone: true, selector: "dock-manager-core", inputs: { initialState: "initialState", widgets: "widgets", createContent: "createContent", createTab: "createTab", createHeaderActions: "createHeaderActions", createWatermark: "createWatermark", theme: "theme", allowRootDock: "allowRootDock" }, outputs: { ready: "ready", stateChange: "stateChange", willClose: "willClose", willDrop: "willDrop", saveLayout: "saveLayout" }, viewQueries: [{ propertyName: "containerRef", first: true, predicate: ["container"], descendants: true, static: true }], usesOnChanges: true, ngImport: i0, template: `<div #container style="width:100%;height:100%"></div>`, isInline: true, styles: [":host{display:block;width:100%;height:100%;overflow:hidden}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: DockManagerCoreComponent, decorators: [{
            type: Component,
            args: [{ selector: 'dock-manager-core', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: `<div #container style="width:100%;height:100%"></div>`, styles: [":host{display:block;width:100%;height:100%;overflow:hidden}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }, { type: i0.ApplicationRef }, { type: i0.EnvironmentInjector }], propDecorators: { initialState: [{
                type: Input
            }], widgets: [{
                type: Input
            }], createContent: [{
                type: Input
            }], createTab: [{
                type: Input
            }], createHeaderActions: [{
                type: Input
            }], createWatermark: [{
                type: Input
            }], theme: [{
                type: Input
            }], allowRootDock: [{
                type: Input
            }], ready: [{
                type: Output
            }], stateChange: [{
                type: Output
            }], willClose: [{
                type: Output
            }], willDrop: [{
                type: Output
            }], saveLayout: [{
                type: Output
            }], containerRef: [{
                type: ViewChild,
                args: ['container', { static: true }]
            }] } });

class DockThemeService {
    themeModeSubject = new BehaviorSubject('light');
    mediaQueryList = null;
    mediaQueryListener = null;
    themeMode$ = this.themeModeSubject.asObservable();
    constructor() {
        this.initializeSystemModeListener();
    }
    setThemeMode(mode) {
        this.themeModeSubject.next(mode);
        this.applyTheme(mode);
    }
    getThemeMode() {
        return this.themeModeSubject.getValue();
    }
    applyTheme(mode) {
        const root = document.documentElement;
        const isDark = mode === 'dark' || (mode === 'system' && this.isSystemDark());
        if (isDark) {
            root.classList.add('dark');
        }
        else {
            root.classList.remove('dark');
        }
    }
    isSystemDark() {
        if (typeof window === 'undefined')
            return false;
        return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    initializeSystemModeListener() {
        if (typeof window === 'undefined')
            return;
        try {
            this.mediaQueryList = window.matchMedia('(prefers-color-scheme: dark)');
            this.mediaQueryListener = (e) => {
                const currentMode = this.themeModeSubject.getValue();
                if (currentMode === 'system') {
                    this.applyTheme('system');
                }
            };
            this.mediaQueryList.addEventListener('change', this.mediaQueryListener);
        }
        catch (e) {
            console.warn('System theme detection not supported', e);
        }
    }
    ngOnDestroy() {
        if (this.mediaQueryList && this.mediaQueryListener) {
            this.mediaQueryList.removeEventListener('change', this.mediaQueryListener);
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: DockThemeService, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: DockThemeService, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.0", ngImport: i0, type: DockThemeService, decorators: [{
            type: Injectable,
            args: [{
                    providedIn: 'root',
                }]
        }], ctorParameters: () => [] });

// Core-owned DOM architecture

/**
 * Generated bundle index. Do not edit.
 */

export { DockManagerCoreComponent, DockThemeService };
//# sourceMappingURL=widgetstools-angular-dock-manager.mjs.map
