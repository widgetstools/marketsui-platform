import type { FilterDisplay, FilterDisplayParams, FloatingFilterDisplay, FloatingFilterDisplayParams, ICellEditor, ICellEditorParams, ICellEditorRendererParams, ICellRenderer, ICellRendererParams, IDate, IDateParams, IDragAndDropImage, IDragAndDropImageParams, IExportingOverlay, IExportingOverlayParams, IFilter, IFilterParams, IFloatingFilter, IFloatingFilterParams, IHeader, IHeaderGroup, IHeaderGroupParams, IHeaderParams, ILoadingCellRendererParams, ILoadingOverlay, ILoadingOverlayParams, IMenuItem, IMenuItemParams, INoMatchingRowsOverlay, INoMatchingRowsOverlayParams, INoRowsOverlay, INoRowsOverlayParams, IOverlay, IOverlayParams, IStatusPanel, IStatusPanelParams, IToolPanel, IToolPanelParams, ITooltipParams } from 'ag-grid-community';
export interface AgFrameworkComponent<T> {
    /** Mandatory - Params for rendering this component. */
    agInit(params: T): void;
}
export interface IHeaderGroupAngularComp extends AgFrameworkComponent<IHeaderGroupParams>, IHeaderGroup {
}
export interface IInnerHeaderGroupAngularComp extends AgFrameworkComponent<IHeaderGroupParams>, IHeaderGroup {
}
export interface IHeaderAngularComp extends AgFrameworkComponent<IHeaderParams>, IHeader {
}
export interface IInnerHeaderAngularComp extends AgFrameworkComponent<IHeaderParams>, IHeader {
}
export interface IFloatingFilterAngularComp<P = any> extends AgFrameworkComponent<IFloatingFilterParams<P>>, IFloatingFilter {
}
export interface IFloatingFilterDisplayAngularComp<TData = any, TContext = any, TModel = any, TCustomParams = object> extends AgFrameworkComponent<FloatingFilterDisplayParams<TData, TContext, TModel, TCustomParams>>, FloatingFilterDisplay<TData, TContext, TModel, TCustomParams> {
}
export interface IDateAngularComp extends AgFrameworkComponent<IDateParams>, IDate {
}
export interface IDragAndDropImageAngularComponent extends AgFrameworkComponent<IDragAndDropImageParams>, IDragAndDropImage {
}
export interface IFilterAngularComp extends AgFrameworkComponent<IFilterParams>, IFilter {
}
export interface IFilterDisplayAngularComp<TData = any, TContext = any, TModel = any, TState = any> extends AgFrameworkComponent<FilterDisplayParams<TData, TContext, TModel, TState>>, FilterDisplay<TData, TContext, TModel, TState> {
}
export interface ICellRendererAngularComp extends AgFrameworkComponent<ICellRendererParams>, ICellRenderer {
}
export interface ICellEditorRendererAngularComp extends AgFrameworkComponent<ICellEditorRendererParams> {
}
export interface ICellEditorAngularComp extends AgFrameworkComponent<ICellEditorParams>, ICellEditor {
}
export interface AgRendererComponent extends ICellRendererAngularComp {
}
export interface AgEditorComponent extends ICellEditorAngularComp {
}
export interface AgFilterComponent extends IFilterAngularComp {
}
export interface AgFloatingFilterComponent extends IFloatingFilterAngularComp {
}
export interface ILoadingCellRendererAngularComp extends AgFrameworkComponent<ILoadingCellRendererParams> {
}
export interface IOverlayAngularComp extends AgFrameworkComponent<IOverlayParams>, IOverlay {
}
export interface ILoadingOverlayAngularComp extends AgFrameworkComponent<ILoadingOverlayParams>, ILoadingOverlay {
}
export interface IExportingOverlayAngularComp extends AgFrameworkComponent<IExportingOverlayParams>, IExportingOverlay {
}
export interface INoRowsOverlayAngularComp extends AgFrameworkComponent<INoRowsOverlayParams>, INoRowsOverlay {
}
export interface INoMatchingRowsOverlayAngularComp extends AgFrameworkComponent<INoMatchingRowsOverlayParams>, INoMatchingRowsOverlay {
}
export interface IStatusPanelAngularComp extends AgFrameworkComponent<IStatusPanelParams>, IStatusPanel {
}
export interface IToolPanelAngularComp extends AgFrameworkComponent<IToolPanelParams>, IToolPanel {
}
export interface ITooltipAngularComp extends AgFrameworkComponent<ITooltipParams> {
}
export interface IMenuItemAngularComp extends AgFrameworkComponent<IMenuItemParams>, IMenuItem {
}
