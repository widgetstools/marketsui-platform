import type { AngularFrameworkOverrides } from './angularFrameworkOverrides';
type EventTypeToWrap = string;
export declare class AngularFrameworkEventListenerService<TEventListener extends (e: any) => void, TGlobalEventListener extends (name: string, e: any) => void> {
    private readonly frameworkOverrides;
    private readonly wrappedListeners;
    private readonly wrappedGlobalListeners;
    constructor(frameworkOverrides: AngularFrameworkOverrides);
    wrap(eventType: EventTypeToWrap, userListener: TEventListener): TEventListener;
    wrapGlobal(userListener: TGlobalEventListener): TGlobalEventListener;
    unwrap(eventType: EventTypeToWrap, userListener: TEventListener): TEventListener;
    unwrapGlobal(userListener: TGlobalEventListener): TGlobalEventListener;
}
export {};
