import type { ComponentRef } from '@angular/core';
import { ViewContainerRef } from '@angular/core';
import type { FrameworkComponentWrapper, WrappableInterface } from 'ag-grid-community';
import { BaseComponentWrapper } from 'ag-grid-community';
import type { AngularFrameworkOverrides } from './angularFrameworkOverrides';
import * as i0 from "@angular/core";
export declare class AgComponentContainer {
    vcr: ViewContainerRef;
    static ɵfac: i0.ɵɵFactoryDeclaration<AgComponentContainer, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<AgComponentContainer, "ag-component-container", never, {}, {}, never, never, false, never>;
}
export declare class AngularFrameworkComponentWrapper extends BaseComponentWrapper<WrappableInterface> implements FrameworkComponentWrapper {
    private viewContainerRef;
    private angularFrameworkOverrides;
    private compShards;
    setViewContainerRef(viewContainerRef: ViewContainerRef, angularFrameworkOverrides: AngularFrameworkOverrides): void;
    protected createWrapper(OriginalConstructor: {
        new (): any;
    }): WrappableInterface;
    createComponent<T>(componentType: {
        new (...args: any[]): T;
    }): ComponentRef<T>;
    static ɵfac: i0.ɵɵFactoryDeclaration<AngularFrameworkComponentWrapper, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AngularFrameworkComponentWrapper>;
}
