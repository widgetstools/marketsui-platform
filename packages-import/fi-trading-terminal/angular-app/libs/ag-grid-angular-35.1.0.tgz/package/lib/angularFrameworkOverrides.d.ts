import { NgZone } from '@angular/core';
import type { FrameworkOverridesIncomingSource, IFrameworkEventListenerService, LocalEventService } from 'ag-grid-community';
import { VanillaFrameworkOverrides } from 'ag-grid-community';
import * as i0 from "@angular/core";
export declare class AngularFrameworkOverrides extends VanillaFrameworkOverrides {
    private readonly _ngZone;
    readonly batchFrameworkComps: boolean;
    private readonly isRunningWithinTestZone;
    private readonly runOutside;
    constructor(_ngZone: NgZone);
    wrapIncoming: <T>(callback: () => T, source?: FrameworkOverridesIncomingSource) => T;
    /**
     * The shouldWrapOutgoing property is used to determine if events should be run outside of Angular or not.
     * If an event handler is registered outside of Angular then we should not wrap the event handler
     * with runInsideAngular() as the user may not have wanted this.
     * This is also used to not wrap internal event listeners that are registered with RowNodes and Columns.
     */
    get shouldWrapOutgoing(): boolean;
    /**
     * Make sure that any code that is executed outside of AG Grid is running within the Angular zone.
     * This means users can update templates and use binding without having to do anything extra.
     */
    wrapOutgoing: <T>(callback: () => T) => T;
    createLocalEventListenerWrapper(existingFrameworkEventListenerService: IFrameworkEventListenerService<any, any> | undefined, localEventService: LocalEventService<any>): IFrameworkEventListenerService<any, any> | undefined;
    createGlobalEventListenerWrapper(): IFrameworkEventListenerService<any, any>;
    isFrameworkComponent(comp: any): boolean;
    runInsideAngular<T>(callback: () => T): T;
    runOutsideAngular<T>(callback: () => T, source?: FrameworkOverridesIncomingSource): T;
    static ɵfac: i0.ɵɵFactoryDeclaration<AngularFrameworkOverrides, never>;
    static ɵprov: i0.ɵɵInjectableDeclaration<AngularFrameworkOverrides>;
}
