/**
 * @license
 * Copyright Google LLC All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.dev/license
 */
export * from './src/compiler';
export { NgCompilerHost } from './src/host';
export { UnifiedModulesHost, NgCompilerOptions, DiagnosticCategoryLabel } from './api';
