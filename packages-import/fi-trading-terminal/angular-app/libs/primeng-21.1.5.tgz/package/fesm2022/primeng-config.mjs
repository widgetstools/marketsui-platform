import * as i0 from '@angular/core';
import { signal, inject, effect, untracked, Injectable, PLATFORM_ID, InjectionToken, provideAppInitializer, makeEnvironmentProviders } from '@angular/core';
import { FilterMatchMode } from 'primeng/api';
import { Subject } from 'rxjs';
import { DOCUMENT } from '@angular/common';
import { ThemeService, Theme } from '@primeuix/styled';
import { BaseStyle } from 'primeng/base';

class ThemeProvider {
    // @todo define type for theme
    theme = signal(undefined, ...(ngDevMode ? [{ debugName: "theme" }] : /* istanbul ignore next */ []));
    csp = signal({ nonce: undefined }, ...(ngDevMode ? [{ debugName: "csp" }] : /* istanbul ignore next */ []));
    isThemeChanged = false;
    document = inject(DOCUMENT);
    baseStyle = inject(BaseStyle);
    constructor() {
        effect(() => {
            ThemeService.on('theme:change', (newTheme) => {
                untracked(() => {
                    this.isThemeChanged = true;
                    this.theme.set(newTheme);
                    // this.onThemeChange(this.theme());
                });
            });
        });
        effect(() => {
            const themeValue = this.theme();
            if (this.document && themeValue) {
                if (!this.isThemeChanged) {
                    this.onThemeChange(themeValue);
                }
                this.isThemeChanged = false;
            }
        });
    }
    ngOnDestroy() {
        Theme.clearLoadedStyleNames();
        ThemeService.clear();
    }
    onThemeChange(value) {
        Theme.setTheme(value);
        if (this.document) {
            this.loadCommonTheme();
        }
    }
    loadCommonTheme() {
        if (this.theme() === 'none')
            return;
        // common
        if (!Theme.isStyleNameLoaded('common')) {
            const { primitive, semantic, global, style } = this.baseStyle.getCommonTheme?.() || {};
            const styleOptions = { nonce: this.csp?.()?.nonce };
            this.baseStyle.load(primitive?.css, { name: 'primitive-variables', ...styleOptions });
            this.baseStyle.load(semantic?.css, { name: 'semantic-variables', ...styleOptions });
            this.baseStyle.load(global?.css, { name: 'global-variables', ...styleOptions });
            this.baseStyle.loadBaseStyle({ name: 'global-style', ...styleOptions }, style);
            Theme.setLoadedStyleName('common');
        }
    }
    setThemeConfig(config) {
        const { theme, csp } = config || {};
        if (theme)
            this.theme.set(theme);
        if (csp)
            this.csp.set(csp);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: ThemeProvider, deps: [], target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: ThemeProvider, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: ThemeProvider, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }], ctorParameters: () => [] });

class PrimeNG extends ThemeProvider {
    ripple = signal(false, ...(ngDevMode ? [{ debugName: "ripple" }] : /* istanbul ignore next */ []));
    platformId = inject(PLATFORM_ID);
    /**
     * @deprecated Since v20. Use `inputVariant` instead.
     */
    inputStyle = signal(null, ...(ngDevMode ? [{ debugName: "inputStyle" }] : /* istanbul ignore next */ []));
    inputVariant = signal(null, ...(ngDevMode ? [{ debugName: "inputVariant" }] : /* istanbul ignore next */ []));
    overlayAppendTo = signal('self', ...(ngDevMode ? [{ debugName: "overlayAppendTo" }] : /* istanbul ignore next */ []));
    overlayOptions = {};
    csp = signal({ nonce: undefined }, ...(ngDevMode ? [{ debugName: "csp" }] : /* istanbul ignore next */ []));
    unstyled = signal(undefined, ...(ngDevMode ? [{ debugName: "unstyled" }] : /* istanbul ignore next */ []));
    pt = signal(undefined, ...(ngDevMode ? [{ debugName: "pt" }] : /* istanbul ignore next */ []));
    ptOptions = signal(undefined, ...(ngDevMode ? [{ debugName: "ptOptions" }] : /* istanbul ignore next */ []));
    filterMatchModeOptions = {
        text: [FilterMatchMode.STARTS_WITH, FilterMatchMode.CONTAINS, FilterMatchMode.NOT_CONTAINS, FilterMatchMode.ENDS_WITH, FilterMatchMode.EQUALS, FilterMatchMode.NOT_EQUALS],
        numeric: [FilterMatchMode.EQUALS, FilterMatchMode.NOT_EQUALS, FilterMatchMode.LESS_THAN, FilterMatchMode.LESS_THAN_OR_EQUAL_TO, FilterMatchMode.GREATER_THAN, FilterMatchMode.GREATER_THAN_OR_EQUAL_TO],
        date: [FilterMatchMode.DATE_IS, FilterMatchMode.DATE_IS_NOT, FilterMatchMode.DATE_BEFORE, FilterMatchMode.DATE_AFTER]
    };
    translation = {
        startsWith: 'Starts with',
        contains: 'Contains',
        notContains: 'Not contains',
        endsWith: 'Ends with',
        equals: 'Equals',
        notEquals: 'Not equals',
        noFilter: 'No Filter',
        lt: 'Less than',
        lte: 'Less than or equal to',
        gt: 'Greater than',
        gte: 'Greater than or equal to',
        is: 'Is',
        isNot: 'Is not',
        before: 'Before',
        after: 'After',
        dateIs: 'Date is',
        dateIsNot: 'Date is not',
        dateBefore: 'Date is before',
        dateAfter: 'Date is after',
        clear: 'Clear',
        apply: 'Apply',
        matchAll: 'Match All',
        matchAny: 'Match Any',
        addRule: 'Add Rule',
        removeRule: 'Remove Rule',
        accept: 'Yes',
        reject: 'No',
        choose: 'Choose',
        completed: 'Completed',
        upload: 'Upload',
        cancel: 'Cancel',
        pending: 'Pending',
        fileSizeTypes: ['B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'],
        dayNames: ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
        dayNamesShort: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
        dayNamesMin: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
        monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
        monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
        chooseYear: 'Choose Year',
        chooseMonth: 'Choose Month',
        chooseDate: 'Choose Date',
        prevDecade: 'Previous Decade',
        nextDecade: 'Next Decade',
        prevYear: 'Previous Year',
        nextYear: 'Next Year',
        prevMonth: 'Previous Month',
        nextMonth: 'Next Month',
        prevHour: 'Previous Hour',
        nextHour: 'Next Hour',
        prevMinute: 'Previous Minute',
        nextMinute: 'Next Minute',
        prevSecond: 'Previous Second',
        nextSecond: 'Next Second',
        am: 'am',
        pm: 'pm',
        dateFormat: 'mm/dd/yy',
        firstDayOfWeek: 0,
        today: 'Today',
        weekHeader: 'Wk',
        weak: 'Weak',
        medium: 'Medium',
        strong: 'Strong',
        passwordPrompt: 'Enter a password',
        emptyMessage: 'No results found',
        searchMessage: 'Search results are available',
        selectionMessage: '{0} items selected',
        emptySelectionMessage: 'No selected item',
        emptySearchMessage: 'No results found',
        emptyFilterMessage: 'No results found',
        fileChosenMessage: 'Files',
        noFileChosenMessage: 'No file chosen',
        aria: {
            trueLabel: 'True',
            falseLabel: 'False',
            nullLabel: 'Not Selected',
            star: '1 star',
            stars: '{star} stars',
            selectAll: 'All items selected',
            unselectAll: 'All items unselected',
            close: 'Close',
            previous: 'Previous',
            next: 'Next',
            navigation: 'Navigation',
            scrollTop: 'Scroll Top',
            moveTop: 'Move Top',
            moveUp: 'Move Up',
            moveDown: 'Move Down',
            moveBottom: 'Move Bottom',
            moveToTarget: 'Move to Target',
            moveToSource: 'Move to Source',
            moveAllToTarget: 'Move All to Target',
            moveAllToSource: 'Move All to Source',
            pageLabel: '{page}',
            firstPageLabel: 'First Page',
            lastPageLabel: 'Last Page',
            nextPageLabel: 'Next Page',
            prevPageLabel: 'Previous Page',
            rowsPerPageLabel: 'Rows per page',
            previousPageLabel: 'Previous Page',
            jumpToPageDropdownLabel: 'Jump to Page Dropdown',
            jumpToPageInputLabel: 'Jump to Page Input',
            selectRow: 'Row Selected',
            unselectRow: 'Row Unselected',
            expandRow: 'Row Expanded',
            collapseRow: 'Row Collapsed',
            showFilterMenu: 'Show Filter Menu',
            hideFilterMenu: 'Hide Filter Menu',
            filterOperator: 'Filter Operator',
            filterConstraint: 'Filter Constraint',
            editRow: 'Row Edit',
            saveEdit: 'Save Edit',
            cancelEdit: 'Cancel Edit',
            listView: 'List View',
            gridView: 'Grid View',
            slide: 'Slide',
            slideNumber: '{slideNumber}',
            zoomImage: 'Zoom Image',
            zoomIn: 'Zoom In',
            zoomOut: 'Zoom Out',
            rotateRight: 'Rotate Right',
            rotateLeft: 'Rotate Left',
            listLabel: 'Option List',
            selectColor: 'Select a color',
            removeLabel: 'Remove',
            browseFiles: 'Browse Files',
            maximizeLabel: 'Maximize',
            minimizeLabel: 'Minimize'
        }
    };
    zIndex = {
        modal: 1100,
        overlay: 1000,
        menu: 1000,
        tooltip: 1100
    };
    translationSource = new Subject();
    translationObserver = this.translationSource.asObservable();
    getTranslation(key) {
        return this.translation[key];
    }
    setTranslation(value) {
        this.translation = { ...this.translation, ...value };
        this.translationSource.next(this.translation);
    }
    setConfig(config) {
        const { csp, ripple, inputStyle, inputVariant, theme, overlayOptions, translation, filterMatchModeOptions, overlayAppendTo, zIndex, ptOptions, pt, unstyled } = config || {};
        if (csp)
            this.csp.set(csp);
        if (overlayAppendTo)
            this.overlayAppendTo.set(overlayAppendTo);
        if (ripple)
            this.ripple.set(ripple);
        if (inputStyle)
            this.inputStyle.set(inputStyle);
        if (inputVariant)
            this.inputVariant.set(inputVariant);
        if (overlayOptions)
            this.overlayOptions = overlayOptions;
        if (translation)
            this.setTranslation(translation);
        if (filterMatchModeOptions)
            this.filterMatchModeOptions = filterMatchModeOptions;
        if (zIndex)
            this.zIndex = zIndex;
        if (pt)
            this.pt.set(pt);
        if (ptOptions)
            this.ptOptions.set(ptOptions);
        if (unstyled)
            this.unstyled.set(unstyled);
        if (theme)
            this.setThemeConfig({
                theme,
                csp
            });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: PrimeNG, deps: null, target: i0.ɵɵFactoryTarget.Injectable });
    static ɵprov = i0.ɵɵngDeclareInjectable({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: PrimeNG, providedIn: 'root' });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.6", ngImport: i0, type: PrimeNG, decorators: [{
            type: Injectable,
            args: [{ providedIn: 'root' }]
        }] });

const PRIME_NG_CONFIG = new InjectionToken('PRIME_NG_CONFIG');
function providePrimeNG(...features) {
    const providers = features?.map((feature) => ({
        provide: PRIME_NG_CONFIG,
        useValue: feature,
        multi: false
    }));
    const initializer = provideAppInitializer(() => {
        const PrimeNGConfig = inject(PrimeNG);
        features?.forEach((feature) => PrimeNGConfig.setConfig(feature));
        return;
    });
    return makeEnvironmentProviders([...providers, initializer]);
}

/**
 * Generated bundle index. Do not edit.
 */

export { PRIME_NG_CONFIG, PrimeNG, ThemeProvider, providePrimeNG };
//# sourceMappingURL=primeng-config.mjs.map
