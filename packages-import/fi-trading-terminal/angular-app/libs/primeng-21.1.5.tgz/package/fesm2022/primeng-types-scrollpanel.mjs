/**
 * Generated bundle index. Do not edit.
 */
//# sourceMappingURL=primeng-types-scrollpanel.mjs.map
