import { TemplateRef } from '@angular/core';
import { MotionOptions } from '@primeuix/motion';
import { PassThrough, PassThroughOption } from 'primeng/api';
import { InputTextPassThrough } from 'primeng/types/inputtext';
import { OverlayPassThrough } from 'primeng/types/overlay';

/**
 * Custom pass-through(pt) options.
 * @template I Type of instance.
 *
 * @see {@link Password.pt}
 * @group Interface
 */
interface PasswordPassThroughOptions<I = unknown> {
    /**
     * Used to pass attributes to the host element.
     */
    host?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the root's DOM element.
     */
    root?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the InputText component.
     * @see {@link InputTextPassThrough}
     */
    pcInputText?: InputTextPassThrough;
    /**
     * Used to pass attributes to the clear icon's DOM element.
     */
    clearIcon?: PassThroughOption<HTMLElement, I>;
    /**
     * Used to pass attributes to the mask icon's DOM element.
     */
    maskIcon?: PassThroughOption<HTMLElement, I>;
    /**
     * Used to pass attributes to the unmask icon's DOM element.
     */
    unmaskIcon?: PassThroughOption<HTMLElement, I>;
    /**
     * Used to pass attributes to the Overlay component.
     * @see {@link OverlayPassThrough}
     */
    pcOverlay?: OverlayPassThrough;
    /**
     * Used to pass attributes to the overlay's DOM element.
     */
    overlay?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the content's DOM element.
     */
    content?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the meter's DOM element.
     */
    meter?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the meter label's DOM element.
     */
    meterLabel?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the meter text's DOM element.
     */
    meterText?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass options to the motion component/directive.
     */
    motion?: MotionOptions;
}
/**
 * Defines valid pass-through options in Password.
 * @see {@link PasswordPassThroughOptions}
 *
 * @template I Type of instance.
 */
type PasswordPassThrough<I = unknown> = PassThrough<I, PasswordPassThroughOptions<I>>;
/**
 * Custom icon template context.
 * @group Interface
 */
interface PasswordIconTemplateContext {
    /**
     * Style class of the icon.
     */
    class: string;
}
/**
 * Defines valid templates in Password.
 * @group Templates
 */
interface PasswordTemplates {
    /**
     * Custom template of header.
     */
    header(): TemplateRef<void>;
    /**
     * Custom template of content.
     */
    content(): TemplateRef<void>;
    /**
     * Custom template of footer.
     */
    footer(): TemplateRef<void>;
    /**
     * Custom template of clear icon.
     */
    clearicon(): TemplateRef<void>;
    /**
     * Custom template of hide icon.
     * @param {PasswordIconTemplateContext} context - icon context.
     */
    hideicon(context: PasswordIconTemplateContext): TemplateRef<PasswordIconTemplateContext>;
    /**
     * Custom template of show icon.
     * @param {PasswordIconTemplateContext} context - icon context.
     */
    showicon(context: PasswordIconTemplateContext): TemplateRef<PasswordIconTemplateContext>;
}

export type { PasswordIconTemplateContext, PasswordPassThrough, PasswordPassThroughOptions, PasswordTemplates };
