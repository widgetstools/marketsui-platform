import { TemplateRef } from '@angular/core';
import { MenuItem, PassThrough, PassThroughOption } from 'primeng/api';
import { BadgePassThrough } from 'primeng/types/badge';

/**
 * Custom pass-through(pt) options.
 * @template I Type of instance.
 *
 * @see {@link Menubar.pt}
 * @group Interface
 */
interface MenubarPassThroughOptions<I = unknown> {
    /**
     * Used to pass attributes to the root's DOM element.
     */
    root?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the root list's DOM element.
     */
    rootList?: PassThroughOption<HTMLUListElement, I>;
    /**
     * Used to pass attributes to the item's DOM element.
     */
    item?: PassThroughOption<HTMLLIElement, I>;
    /**
     * Used to pass attributes to the item content's DOM element.
     */
    itemContent?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the item link's DOM element.
     */
    itemLink?: PassThroughOption<HTMLAnchorElement, I>;
    /**
     * Used to pass attributes to the item icon's DOM element.
     */
    itemIcon?: PassThroughOption<HTMLSpanElement, I>;
    /**
     * Used to pass attributes to the item label's DOM element.
     */
    itemLabel?: PassThroughOption<HTMLSpanElement, I>;
    /**
     * Used to pass attributes to the submenu icon's DOM element.
     */
    submenuIcon?: PassThroughOption<SVGElement, I>;
    /**
     * Used to pass attributes to the separator's DOM element.
     */
    separator?: PassThroughOption<HTMLLIElement, I>;
    /**
     * Used to pass attributes to the mobile menu button's DOM element.
     */
    button?: PassThroughOption<HTMLAnchorElement, I>;
    /**
     * Used to pass attributes to the mobile menu button icon's DOM element.
     */
    buttonIcon?: PassThroughOption<SVGElement, I>;
    /**
     * Used to pass attributes to the submenu's DOM element.
     */
    submenu?: PassThroughOption<HTMLUListElement, I>;
    /**
     * Used to pass attributes to the start of the component.
     */
    start?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to the end of the component.
     */
    end?: PassThroughOption<HTMLDivElement, I>;
    /**
     * Used to pass attributes to Badge component.
     * @see {@link BadgePassThrough}
     */
    pcBadge?: BadgePassThrough;
}
/**
 * Defines valid pass-through options in Menubar.
 * @see {@link MenubarPassThroughOptions}
 *
 * @template I Type of instance.
 */
type MenubarPassThrough<I = unknown> = PassThrough<I, MenubarPassThroughOptions<I>>;
/**
 * Custom item template context.
 * @group Interface
 */
interface MenubarItemTemplateContext {
    /**
     * Menu item instance.
     */
    $implicit: MenuItem;
    /**
     * Whether the item is at the root level.
     */
    root: boolean;
}
/**
 * Defines valid templates in Menubar.
 * @group Templates
 */
interface MenubarTemplates {
    /**
     * Custom item template.
     * @param {Object} context - item context.
     */
    item(context: MenubarItemTemplateContext): TemplateRef<MenubarItemTemplateContext>;
    /**
     * Custom template of start.
     */
    start(): TemplateRef<void>;
    /**
     * Custom template of end.
     */
    end(): TemplateRef<void>;
    /**
     * Custom template of menu icon.
     */
    menuicon(): TemplateRef<void>;
    /**
     * Custom template of submenu icon.
     */
    submenuicon(): TemplateRef<void>;
}

export type { MenubarItemTemplateContext, MenubarPassThrough, MenubarPassThroughOptions, MenubarTemplates };
