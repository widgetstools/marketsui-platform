import { BaseComponent } from 'primeng/basecomponent';
import * as i0 from '@angular/core';

interface AnimateOnScrollOptions {
    root?: HTMLElement | null;
    rootMargin?: string;
    threshold?: number;
}
/**
 * AnimateOnScroll is used to apply animations to elements when entering or leaving the viewport during scrolling.
 * @group Components
 */
declare class AnimateOnScroll extends BaseComponent {
    /**
     * Selector to define the CSS class for enter animation.
     * @group Props
     */
    enterClass: string | undefined;
    /**
     * Selector to define the CSS class for leave animation.
     * @group Props
     */
    leaveClass: string | undefined;
    /**
     * Specifies the root option of the IntersectionObserver API.
     * @group Props
     */
    root: HTMLElement | undefined | null;
    /**
     * Specifies the rootMargin option of the IntersectionObserver API.
     * @group Props
     */
    rootMargin: string | undefined;
    /**
     * Specifies the threshold option of the IntersectionObserver API
     * @group Props
     */
    threshold: number | undefined;
    /**
     * Whether the scroll event listener should be removed after initial run.
     * @group Props
     */
    once: boolean;
    observer: IntersectionObserver | undefined;
    resetObserver: any;
    isObserverActive: boolean;
    animationState: any;
    animationEndListener: VoidFunction | null | undefined;
    onInit(): void;
    onAfterViewInit(): void;
    get options(): AnimateOnScrollOptions;
    bindIntersectionObserver(): void;
    enter(): void;
    leave(): void;
    bindAnimationEvents(): void;
    unbindAnimationEvents(): void;
    unbindIntersectionObserver(): void;
    onDestroy(): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimateOnScroll, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<AnimateOnScroll, "[pAnimateOnScroll]", never, { "enterClass": { "alias": "enterClass"; "required": false; }; "leaveClass": { "alias": "leaveClass"; "required": false; }; "root": { "alias": "root"; "required": false; }; "rootMargin": { "alias": "rootMargin"; "required": false; }; "threshold": { "alias": "threshold"; "required": false; }; "once": { "alias": "once"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_threshold: unknown;
    static ngAcceptInputType_once: unknown;
}
declare class AnimateOnScrollModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<AnimateOnScrollModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<AnimateOnScrollModule, never, [typeof AnimateOnScroll], [typeof AnimateOnScroll]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<AnimateOnScrollModule>;
}

export { AnimateOnScroll, AnimateOnScrollModule };
