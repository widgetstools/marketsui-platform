import * as i0 from '@angular/core';
import { SimpleChanges } from '@angular/core';
import { BaseComponent } from 'primeng/basecomponent';

/**
 * Focus Trap keeps focus within a certain DOM element while tabbing.
 * @group Components
 */
declare class FocusTrap extends BaseComponent {
    /**
     * When set as true, focus wouldn't be managed.
     * @group Props
     */
    pFocusTrapDisabled: boolean;
    platformId: Object;
    document: Document;
    firstHiddenFocusableElement: HTMLElement;
    lastHiddenFocusableElement: HTMLElement;
    onInit(): void;
    onChanges(changes: SimpleChanges): void;
    removeHiddenFocusableElements(): void;
    getComputedSelector(selector: any): string;
    createHiddenFocusableElements(): void;
    onFirstHiddenElementFocus(event: any): void;
    onLastHiddenElementFocus(event: any): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusTrap, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FocusTrap, "[pFocusTrap]", never, { "pFocusTrapDisabled": { "alias": "pFocusTrapDisabled"; "required": false; }; }, {}, never, never, true, never>;
    static ngAcceptInputType_pFocusTrapDisabled: unknown;
}
declare class FocusTrapModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<FocusTrapModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<FocusTrapModule, never, [typeof FocusTrap], [typeof FocusTrap]>;
    static ɵinj: i0.ɵɵInjectorDeclaration<FocusTrapModule>;
}

export { FocusTrap, FocusTrapModule };
